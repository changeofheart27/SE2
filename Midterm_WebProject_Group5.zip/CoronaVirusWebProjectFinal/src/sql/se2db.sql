/*Remember to use chcp 1258 or 65001 to work with command prompt

Version 1.1

Authors: 
-Nguyễn Khắc Hiếu
-Nguyễn Duy Thái Sơn
*/

CREATE TABLE se2db_vietnam (
  `id` INT NOT NULL AUTO_INCREMENT,
  `province_name` VARCHAR(45) NOT NULL,
  `current_infected` INT NULL,
  `current_death` INT NULL,
  `current_recovered` INT NULL,
  `date` DATE NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;
INSERT INTO se2db_vietnam (`id`, `province_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('1', 'Hà Nội', '112', '0', '75', '2020-04-19');
INSERT INTO se2db_vietnam (`id`, `province_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('2', 'Hồ Chí Minh', '55', '0', '52', '2020-04-19');
INSERT INTO se2db_vietnam (`id`, `province_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('3', 'Vĩnh Phúc', '19', '0', '13', '2020-04-19');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('4', 'Ninh Bình');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('5', 'Bình Thuận');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('6', 'Quảng Ninh');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('7', 'Đà Nẵng');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('8', 'Hà Nam');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('9', 'Bắc Giang');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('10', 'Hà Tĩnh');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('11', 'Đồng Tháp');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('12', 'Bạc Liêu');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('13', 'Thanh Hóa');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('14', 'Quảng Nam ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('15', 'Tây Ninh');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('16', 'Trà Vinh');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('17', 'Cần Thơ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('18', 'Lào Cai');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('19', 'Thừa Thiên Huế ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('20', 'Ninh Thuận');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('21', 'Bến Tre');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('22', 'Hưng Yên ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('23', 'Hà Giang');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('24', 'Bắc Ninh ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('25', 'Đồng Nai ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('26', 'Hải Dương ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('27', 'Thái Nguyên ');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('28', 'Lai Châu');
INSERT INTO se2db_vietnam (`id`, `province_name`) VALUES ('29', 'Khánh Hoà');


CREATE TABLE se2db_world (
  `id` INT NOT NULL AUTO_INCREMENT,
  `country_name` VARCHAR(45) NOT NULL,
  `current_infected` INT NULL,
  `current_death` INT NULL,
  `current_recovered` INT NULL,
  `date` DATE NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('1', 'United States', '852610', '84191', '48295', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('2', 'Spain', '213024  ', '89250', '22157', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('3', 'Italy', '187327  ', '25085', '54543', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('4', 'France', '159877  ', '21340', '40657', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('5', 'Germany', '151175  ', '5354', '103300', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('6', 'United Kingdom', '138078  ', '18738', '0', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('7', 'Turkey', '98674', '2376', '1477', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('8', 'Iran', '87026', '5481', '64843', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('9', 'China', '82798', '4632', '77207', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('10', 'Russia', '67773 ', '555', '4891', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('11', 'Brazil', '46701', '2940', '25318', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('12', 'Belgium', '42797  ', '6490', '9800', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('13', 'Canada', '40824', '2028', '13986', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('14', 'Netherlands', '35729', '4177', '0', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('15', 'Switzerland', '28496', '1538', '19900', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('16', 'Portugal', '22353', '820', '1201', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('17', 'India', '21797', '686', '4376', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('18', 'Peru', '19250', '530', '7027', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('19', 'Sweden', '16755', '2021', '550', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('20', 'Ireland', '16671', '769', '9233', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('21', 'Austria', '15002', '11694', '522', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('22', 'Israel', '14592', '191', '5334', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('23', 'Saudi Arabia', '13930', '121', '1925', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('24', 'Japan', '11950', '299', '1424', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('25', 'Chile', '11812 ', '168', '5804', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('26', 'Singapore', '11178', '12', '896', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('27', 'Ecuador', '10850', '537', '1262', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('28', 'Pakistan', '10811', '228', '2337', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('29', 'South Korea', '10702', '240', '8411', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('30', 'Mexico', '10544', '970', '2627', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('31', 'Poland', '10511', '454', '1740', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('32', 'Romania', '10096 ', '541', '2478', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('33', 'United Arab Emirates', '8756', '56', '1637', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('34', 'Denmark', '8073', '394', '5384', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('35', 'Belarus', '8022', '60', '938', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('36', 'Indonesia', '7775', '647', '960', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('37', 'Qatar', '7764', '10', '750', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('38', 'Norway', '7361 ', '191', '32', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('39', 'Serbia', '7276', '139', '1063', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('40', 'Ukraine', '7170', '187', '504', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('41', 'Czechia', '7138', '210', '2152', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('42', 'Philippines', '6981', '462', '772', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('43', 'Australia', '6661', '75', '5045', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('44', 'Malaysia', '5603', '3542', '95', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('45', 'Dominican Republic', '5543', '265', '581', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('46', 'Panama', '4992', '144', '255', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('47', 'Colombia', '4356', '870', '206', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('48', 'Finland', '4284', '2000 ', '172', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('49', 'Bangladesh', '4186', '127', '108', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('50', 'Luxembourg', '3665', '83', '711', '2020-04-24');
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('51','Morocco',3568,155,456,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('52','Argentina',3435,165,919,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('53','Thailand',2839,50,2430,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('54','Greece',2463,125,577,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('55','Kuwait',2399,14,498,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('56','Kazakhstan',2289,20,560,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('57','Hungary',2284,239,390,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('58','Bahrain',2217,8,1082,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('59','Croatia',1981,50,883,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('60','Iceland',1789,10,1509,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('61','Uzbekistan',1758,7,561,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('62','Uzbekistan',1716,9,307,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('63','Iraq',1677,83,1171,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('64','Estonia',1592,45,192,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('65','Azerbaijan',1548,20,948,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('66','Armenia',1523,24,659,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('67','New Zealand',1456,17,1095,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('68','Bosnia Herzegovina',1413,54,485,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('69','Lithuania',1398,40,399,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('70','Slovenia',1366,211,79,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('71','Cameroon',1334,43,668,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('72','Slovakia',1325,15,288,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('73','Macedonia',1300,56,301,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('74','Afghanistan',1279,42,179,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('75','Cuba',1235,365,43,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('76','Ghana',1154,9,99,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('77','Bulgaria',1097,52,190,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('78','Hong Kong',1036,4,699,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('79','Ivory Coast',1004,14,359,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('80','Djibouti',986,2,252,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('81','Nigeria',981,31,197,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('82','Tunisia',981,38,190,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('83','Guinea',862,6,170,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('84','Cyprus',795,13,98,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('85','Latvia',778,11,133,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('86','Andorra',723,37,333,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('87','Diamond Princess',712,13,645,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('88','Bolivia',703,43,44,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('89','Lebanon',688,22,140,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('90','Costa Rica',686,6,196,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('91','Niger',671,24,256,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('92','Albania',663,27,385,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('93','Kyrgyzstan',631,8,302,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('94','Burkina Faso',616,41,410,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('95','Uruguay',557,12,345,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('96','Channel Islands',521,29,295,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('97','Honduras',519,27,31,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('98','San Marino',501,40,63,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('99','Palestine',480,4,92,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('100','Senegal',479,6,257,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('101', 'San Marino', 463, 2, 125,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('102', 'Malta', 447, 3, 223,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('103', 'Jordan', 437, 7, 318,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('104', 'Georgia', 431, 5, 114,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('105', 'Taiwan', 428, 6, 264,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('106', 'Réunion', 412, 0, 238,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('107', 'Congo [DRC]', 394, 25, 48,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('108', 'Guatemala', 384, 11, 30,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('109', 'Sri Lanka', 379, 7, 107,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('110', 'Mayotte', 354, 4, 144,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('111', 'Kenya', 336, 14, 89,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('112', 'Mauritius', 331, 9, 266,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('113', 'Somalia', 328, 16, 8,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('114', 'Montenegro', 319, 10, 123,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('115', 'Venezuela', 311, 10, 126,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('116', 'Mali', 309, 21, 77,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('117', 'Isle of Man', 307, 16, 221,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('118', 'Tanzania', 284, 10, 48,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('119', 'Vietnam', 270, 0, 224,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('120', 'El Salvador', 261, 8, 72,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('121', 'Jamaica', 257, 6, 28,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('122', 'Paraguay', 220, 9, 70,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('123', 'Faeroe Islands', 187, 0, 178,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('124', 'Republic of the Congo', 186, 6, 16,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('125', 'Sudan', 174, 16, 14,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('126', 'Martinique', 170, 14, 77,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('127', 'Gabon', 167, 2, 24,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('128', 'Rwanda', 154, 0, 87,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('129', 'Guadeloupe', 149, 12, 82,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('130', 'Myanmar', 139, 5, 9,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('131', 'Brunei', 138, 1, 120,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('132', 'Gibraltar', 133, 0, 129,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('133', 'Cambodia', 122, 0, 110,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('134', 'Madagascar', 122, 0, 61,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('135', 'Liberia', 117, 8, 25,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('136', 'Ethiopia', 117, 3, 25,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('137', 'Maldives', 116, 0, 16,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('138', 'Trinidad and Tobago', 115, 8, 48,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('139', 'French Guiana', 107, 1, 84,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('140', 'Aruba', 100, 2, 68,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('141', 'Bermuda', 99, 5, 39,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('142', 'Monaco', 94, 4, 35,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('143', 'Togo', 90, 6, 59,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('144', 'Cape Verde', 88, 1, 1,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('145', 'Equatorial Guinea', 84, 1, 7,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('146', 'Sierra Leone', 82, 2, 10,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('147', 'Liechtenstein', 81, 1, 55,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('148', 'Barbados', 76, 6, 30,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('149', 'Zambia', 76, 3, 37,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('150', 'Uganda', 74, 0, 46,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('151', 'Sint Maarten', 73, 12, 22,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('152', 'Bahamas', 72, 11, 14,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('153', 'Haiti', 72, 5, 2,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('154', 'Guyana', 70, 7, 12,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('155', 'Cayman Islands', 66, 1, 7,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('156', 'Libya', 60, 2, 18,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('157', 'French Polynesia', 57, 0, 36,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('158', 'Benin', 54, 1, 27,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('159', 'Guinea-Bissau', 50, 0, 3,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('160', 'Nepal', 48, 0, 10,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('161', 'Mozambique', 46, 0, 12,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('162', 'Macao', 45, 0, 27,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('163', 'Syria', 42, 3, 6,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('164', 'Chad', 40, 0, 8,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('165', 'Eritrea', 39, 0, 11,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('166', 'Saint Martin', 38, 2, 20,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('167', 'Swaziland', 36, 1, 10,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('168', 'Mongolia', 36, 0, 9,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('169', 'Malawi', 33, 3, 3,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('170', 'Zimbabwe', 29, 4, 2,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('171', 'Angola', 25, 2, 6,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('172', 'Antigua and Barbuda', 24, 10, 3,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('173', 'Timor-Leste', 23, 0, 1,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('174', 'Botswana', 22, 0, 1,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('175', 'Laos', 19, 0, 4,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('176', 'Belize', 18, 2, 5,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('177', 'Fiji', 18, 0, 10,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('178', 'New Caledonia', 18, 0, 17,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('179', 'Central African Republic', 16, 0, 10,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('180', 'Dominica', 16, 0, 9,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('181', 'Namibia', 16, 0, 7,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('182', 'Grenada', 15, 0, 7,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('183', 'Saint Kitts and Nevis', 15, 0, 2,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('184', 'Saint Lucia', 15, 0, 15,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('185', 'Curaçao', 14, 1, 11,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('186', 'Saint Vincent and the Grenadines', 14, 0, 5,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('187', 'Falkland Islands', 12, 0, 11,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('188', 'Nicaragua', 11, 3, 7,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('189', 'Burundi', 11, 1, 4,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('190', 'Turks and Caicos', 11, 1, 4,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('191', 'Greenland', 11, 0, 11,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('192', 'Montserrat', 11, 0, 2,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('193', 'Seychelles', 11, 0, 6,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('194', 'Gambia', 10, 1, 2,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('195', 'Suriname', 10, 1, 6,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('196', 'MS Zaandam', 9, 0, 2,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('197', 'Vatican City', 9, 0, 2,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('198', 'Papua New Guinea', 8, 0, 0,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('199', 'Mauritania', 7, 1, 6,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('200', 'Bhutan', 7, 0, 3,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('201', 'St. Barth', 6, 0, 6,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('202', 'Western Sahara', 6, 0, 5,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('203', 'British Virgin Islands', 5, 1, 3,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('204', 'Caribbean Netherlands', 5, 0, 0,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('205', 'South Sudan', 5, 0, 0,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('206', 'Sao Tome and Principe', 4, 0, 0,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('207', 'Anguilla', 3, 0, 1,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('208', 'Saint Pierre Miquelon', 1, 0, 0,NULL);
INSERT INTO se2db_world (`id`, `country_name`, `current_infected`, `current_death`, `current_recovered`, `date`) VALUES ('209', 'Yemen', 1, 0, 1,NULL);

CREATE TABLE se2db_admin (
  `id` INT NOT NULL UNIQUE AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(50) NULL UNIQUE,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

INSERT INTO se2db_admin (`id`, `username`, `password`, `email`) VALUES ('1', 'admin', '123456', NULL);
INSERT INTO se2db_admin (`id`, `username`, `password`, `email`) VALUES ('2', 'duaf1xd', 'duaf1xd', NULL);