package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import CRUDcontrol.AdminDAO;
import model.World;
import okhttp3.OkHttpClient;
import okhttp3.Request;




@WebServlet("/dayOne")
public class DayOne extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession session;
	AdminDAO ad= new AdminDAO();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println("API route caught");
		session=request.getSession();  
		boolean logged_in= false;
    	if(session.getAttribute("admin")== null) System.out.println("Not logged in");
    	if(session.getAttribute("admin")!= null) {
    		System.out.println("Logged in");
    		logged_in= (boolean) session.getAttribute("admin");
    	}
		try {
			if(logged_in) {
				if (action.equals("/dayOne") /*&& ad.getWorldCount()<1000 */) {

					dayOneAPI(request, response);
				}
//				else {
//					RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp?error=Database%20already%20has"
//							+ "%20plenty%20of%20records.%20Consider%20dropping%20table%20then%20retry.");
//			        dispatcher.forward(request, response);
//				}
			}
			else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp?error=Access%20Denied");
		        dispatcher.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void dayOneAPI(HttpServletRequest rq, HttpServletResponse rs)
    		throws ServletException, IOException {
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(30, TimeUnit.SECONDS)
				.writeTimeout(30, TimeUnit.SECONDS)
				.readTimeout(30, TimeUnit.SECONDS)
				.build();
		Request request = new Request.Builder()
				.url("https://api.covid19api.com/all")
				.method("GET", null)
				.build();
		okhttp3.Response response = client.newCall(request).execute();
		System.out.println(response.body());
		
		String data= response.body().string();
		System.out.println(data);
		JSONArray jsonarr = new JSONArray(data);
		System.out.println(jsonarr.get(0));
		ArrayList<JSONObject> list = new ArrayList<JSONObject>();
		for(int i=0; i<jsonarr.length(); ++i) {
			if(i>0) {
				String todayDate= ApiHomepage.dateBuilder(jsonarr.getJSONObject(i).getString("Date"));
				String yesterdayDate= ApiHomepage.dateBuilder(jsonarr.getJSONObject(i-1).getString("Date"));
				if((jsonarr.getJSONObject(i).getString("Country").equals(jsonarr.getJSONObject(i-1).getString("Country")))
						&& (todayDate.equals(yesterdayDate))) {
					if(jsonarr.getJSONObject(i).getInt("Confirmed") < jsonarr.getJSONObject(i-1).getInt("Confirmed")) {
						jsonarr.remove(i);
						--i;
						continue;
					}
					else {
						jsonarr.remove(i-1);
						--i;
						continue;
					}
				}
				else if ((jsonarr.getJSONObject(i).getString("Country").equals(jsonarr.getJSONObject(i-1).getString("Country")))
						&& !(todayDate.equals(yesterdayDate))) {
					if(jsonarr.getJSONObject(i).getInt("Confirmed") < jsonarr.getJSONObject(i-1).getInt("Confirmed")) {
						jsonarr.remove(i);
						--i;
						continue;
					}
					else list.add(jsonarr.getJSONObject(i));
				}
				else list.add(jsonarr.getJSONObject(i));

			}
			else list.add(jsonarr.getJSONObject(i));
		}
		jsonarr= null;
		for(int i=0; i<50; ++i) {
			System.out.println(list.get(i));
		}
		
		for(int i=0; i<list.size(); ++i) {
			JSONObject today= list.get(i);
			JSONObject yesterday;
			if(i>0) {
				yesterday= list.get(i-1);
				if(today.getString("Country").equals(yesterday.getString("Country"))) {
					World wl= new World(today.getString("Country"), 
							today.getInt("Confirmed"),
							today.getInt("Deaths"),
							today.getInt("Recovered"),
							today.getInt("Confirmed")-yesterday.getInt("Confirmed"),
							today.getInt("Deaths")-yesterday.getInt("Deaths"),
							today.getInt("Recovered")-yesterday.getInt("Recovered"),
							ApiHomepage.dateBuilder(today.getString("Date")));
					try {
						ad.insertCountry(wl);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else {
					World wl= new World(today.getString("Country"), 
							today.getInt("Confirmed"),
							today.getInt("Deaths"),
							today.getInt("Recovered"),
							0,
							0,
							0,
							ApiHomepage.dateBuilder(today.getString("Date")));
					try {
						ad.insertCountry(wl);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
			else {
				World wl= new World(today.getString("Country"), 
						today.getInt("Confirmed"),
						today.getInt("Deaths"),
						today.getInt("Recovered"),
						0,
						0,
						0,
						ApiHomepage.dateBuilder(today.getString("Date")));
				try {
					ad.insertCountry(wl);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			
		}


		RequestDispatcher dispatcher = rq.getRequestDispatcher("day-one.jsp");
		dispatcher.forward(rq, rs);
    }

	
}
