package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CRUDcontrol.UserDAO;
import model.Vietnam;
import model.World;

/**
 * Servlet implementation class HomeServlet
 */
@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UserDAO userDAO;
    
    public void init() {
    	userDAO = new UserDAO();
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Date caught "+request.getParameter("date"));
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		String action = request.getServletPath();
		try {
			if (action.equals("/home") && request.getParameter("date")==null && request.getParameter("location")== null) {
				selectAll(request, response);
			}
			else if(action.equals("/home") && request.getParameter("date")!=null && request.getParameter("location")== null) {
				selectAllByDate(request, response);
			}
			else selectAllByLocation(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void selectAll(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException   {
        List<Vietnam> listVietnam = userDAO.selectAllProvinces();
        request.setAttribute("listVietnam", listVietnam);
        
        List<World> listWorld = userDAO.selectAllCountries();
        request.setAttribute("listWorld", listWorld);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
        dispatcher.forward(request, response);
    }

	private void selectAllByDate(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException   {
		System.out.println("Is this run properly with a date param? "+ request.getParameter("date"));
        List<Vietnam> listVietnam = userDAO.selectAllProvinces();
        request.setAttribute("listVietnam", listVietnam);
        
        List<World> listWorld = userDAO.selectAllCountriesByDate(request.getParameter("date"));
        request.setAttribute("listWorld", listWorld);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
        dispatcher.forward(request, response);
    }
	
	private void selectAllByLocation(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException   {
		System.out.println("Is this run properly with a date param? "+ request.getParameter("date"));
        List<Vietnam> listVietnam = userDAO.selectAllProvinces();
        request.setAttribute("listVietnam", listVietnam);
        
        List<World> listWorld = userDAO.selectAllCountriesByLocation(request.getParameter("location"));
        request.setAttribute("listWorld", listWorld);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
        dispatcher.forward(request, response);
    }
}
