package servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.ws.Response;

import org.json.JSONArray;
import org.json.JSONObject;

import CRUDcontrol.AdminDAO;
import model.World;
import okhttp3.OkHttpClient;
import okhttp3.Request;




@WebServlet("/initialize")
public class ApiHomepage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	HttpSession session;
	AdminDAO ad= new AdminDAO();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println("API route caught");
		session=request.getSession();  
		boolean logged_in= false;
    	if(session.getAttribute("admin")== null) System.out.println("Not logged in");
    	if(session.getAttribute("admin")!= null) {
    		System.out.println("Logged in");
    		logged_in= (boolean) session.getAttribute("admin");
    	}
		try {
			if(logged_in) {
				if (action.equals("/initialize") /*&& ad.getTodayCount()<5 */) {

					apiHomepage(request, response);
				}
//				else {
//					RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp?error=There%20is%20%already%20data%20for%20today");
//			        dispatcher.forward(request, response);
//				}
			}
			else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp?error=Access%20Denied");
		        dispatcher.forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void apiHomepage(HttpServletRequest rq, HttpServletResponse rs)
    		throws ServletException, IOException {
		OkHttpClient client = new OkHttpClient().newBuilder()
				.connectTimeout(60, TimeUnit.SECONDS)
				.writeTimeout(60, TimeUnit.SECONDS)
				.readTimeout(60, TimeUnit.SECONDS)
				.build();
		Request request = new Request.Builder()
				.url("https://api.covid19api.com/summary")
				.method("GET", null)
				.build();
		okhttp3.Response response = client.newCall(request).execute();
		System.out.println(response.body());
//		System.out.println(response.body().string());
		String data= response.body().string();
		JSONObject jsonObject = new JSONObject(data);
		JSONObject globalSummary = jsonObject.getJSONObject("Global");
		System.out.println("So many died...: " +globalSummary.getLong("TotalDeaths"));
		
		
		JSONArray countryData= (JSONArray) jsonObject.getJSONArray("Countries");
		ArrayList<JSONObject> list = new ArrayList<JSONObject>();
		for(int i=0; i<countryData.length(); ++i) {
			list.add(countryData.getJSONObject(i));
		}
		
		for(int i=0; i<list.size(); ++i) {
			JSONObject info= list.get(i);
			System.out.println("Country received: "+ info.getString("Country"));
			World wl= new World(info.getString("Country"), 
					info.getInt("TotalConfirmed"),
					info.getInt("TotalDeaths"),
					info.getInt("TotalRecovered"),
					info.getInt("NewConfirmed"),
					info.getInt("NewDeaths"),
					info.getInt("NewRecovered"),
					dateBuilder(info.getString("Date"))
					);
			try {
				ad.insertCountry(wl);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		System.out.println(list);
		
		RequestDispatcher dispatcher = rq.getRequestDispatcher("initialize.jsp");
		dispatcher.forward(rq, rs);
    }

	public static String dateBuilder(String UTCDate) {
		String result= "";
		for(int i=0; i<10; ++i) {
			result+= UTCDate.charAt(i);
		}
		return result;
	}
	
}
