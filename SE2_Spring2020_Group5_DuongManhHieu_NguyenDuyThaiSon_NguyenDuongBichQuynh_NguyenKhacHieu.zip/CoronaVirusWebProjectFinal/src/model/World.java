package model;

public class World {
	private int id;
	private String countryName;
	private int currentInfected;
	private int currentDeath;
	private int currentRecover;
	private int newInfected;
	private int newDeath;
	private int newRecovered;
	private String date;
	
	public World() {
	}

	public World(String countryName, int currentInfected, int currentDeath, int currentRecover,
			int newInfected, int newDeath, String date) {
		super();
		this.countryName = countryName;
		this.currentInfected = currentInfected;
		this.currentDeath = currentDeath;
		this.currentRecover = currentRecover;
		this.newInfected = newInfected;
		this.newDeath = newDeath;
		this.date = date;
	}
	
	public World(String countryName, int currentInfected, int currentDeath, int currentRecover,
			int newInfected, int newDeath) {
		super();
		this.countryName = countryName;
		this.currentInfected = currentInfected;
		this.currentDeath = currentDeath;
		this.currentRecover = currentRecover;
		this.newInfected = newInfected;
		this.newDeath = newDeath;
	}
	
	
	
	public World(String countryName, int currentInfected, int currentDeath, int currentRecover, int newInfected,
			int newDeath, int newRecovered, String date) {
		super();
		this.countryName = countryName;
		this.currentInfected = currentInfected;
		this.currentDeath = currentDeath;
		this.currentRecover = currentRecover;
		this.newInfected = newInfected;
		this.newDeath = newDeath;
		this.newRecovered = newRecovered;
		this.date = date;
	}

	
	
	public World(int id, String countryName, int currentInfected, int currentDeath, int currentRecover, int newInfected,
			int newDeath, int newRecovered, String date) {
		super();
		this.id = id;
		this.countryName = countryName;
		this.currentInfected = currentInfected;
		this.currentDeath = currentDeath;
		this.currentRecover = currentRecover;
		this.newInfected = newInfected;
		this.newDeath = newDeath;
		this.newRecovered = newRecovered;
		this.date = date;
	}

	//CONSTRUCTOR FOR PIECHART
	public World(String countryName, int currentInfected) {
		super();
		this.countryName = countryName;
		this.currentInfected = currentInfected;
	}
	
	//CONSTRUCTOR FOR BARCHART
	public World(String date, int currentInfected, int currentDeath, int currentRecover) {
		super();
		this.date = date;
		this.currentInfected = currentInfected;
		this.currentDeath = currentDeath;
		this.currentRecover = currentRecover;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public int getCurrentInfected() {
		return currentInfected;
	}

	public void setCurrentInfected(int currentInfected) {
		this.currentInfected = currentInfected;
	}

	public int getCurrentDeath() {
		return currentDeath;
	}

	public void setCurrentDeath(int currentDeath) {
		this.currentDeath = currentDeath;
	}

	public int getCurrentRecover() {
		return currentRecover;
	}

	public void setCurrentRecover(int currentRecover) {
		this.currentRecover = currentRecover;
	}
	
	public int getNewInfected() {
		return newInfected;
	}
	
	public void setNewInfected(int newInfected) {
		this.newInfected = newInfected;
	}
	
	public int getNewDeath() {
		return newDeath;
	}
	
	public void setNewDeath(int newDeath) {
		this.newDeath = newDeath;
	}
	
	
	
	public int getNewRecovered() {
		return newRecovered;
	}

	public void setNewRecovered(int newRecovered) {
		this.newRecovered = newRecovered;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
}
