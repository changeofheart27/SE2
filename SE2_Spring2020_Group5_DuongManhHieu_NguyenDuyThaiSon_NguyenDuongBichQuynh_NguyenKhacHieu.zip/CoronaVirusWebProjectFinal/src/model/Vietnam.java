package model;

public class Vietnam {
	private int id;
	private String provinceName;
	private int currentInfected;
	private int currentDeath;
	private int currentRecover;
	private String date;
	
	public Vietnam() {
	}
	
	public Vietnam(String provinceName, int currentInfected, int currentDeath, int currentRecover, String date) {
		super();
		this.provinceName = provinceName;
		this.currentInfected = currentInfected;
		this.currentDeath = currentDeath;
		this.currentRecover = currentRecover;
		this.date = date;
	}

	public Vietnam(int id, String provinceName, int currentInfected, int currentDeath, int currentRecover, String date) {
		super();
		this.id = id;
		this.provinceName = provinceName;
		this.currentInfected = currentInfected;
		this.currentDeath = currentDeath;
		this.currentRecover = currentRecover;
		this.date = date;
	}

	public int getId() {
		return id;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public int getCurrentInfected() {
		return currentInfected;
	}

	public void setCurrentInfected(int currentInfected) {
		this.currentInfected = currentInfected;
	}

	public int getCurrentDeath() {
		return currentDeath;
	}

	public void setCurrentDeath(int currentDeath) {
		this.currentDeath = currentDeath;
	}

	public int getCurrentRecover() {
		return currentRecover;
	}

	public void setCurrentRecover(int currentRecover) {
		this.currentRecover = currentRecover;
	}
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
}
