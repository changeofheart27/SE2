/*Remember to use chcp 1258 or 65001 to work with command prompt

Version 1.8

Authors: 
-Nguyễn Khắc Hiếu
-Nguyễn Duy Thái Sơn
*/

CREATE DATABASE se2db;

USE se2db;
CREATE TABLE `se2db`.`vietnam` (
  `ID` INT NOT NULL AUTO_INCREMENT,
  `Province` VARCHAR(45) NOT NULL,
  `Total Infected` INT NULL,
  `Total Deaths` INT NULL,
  `Total Recovers` INT NULL,
  `Day` DATE NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (1,'Hà Nội',114,0,113,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (2,'Hồ Chí Minh',59,0,54,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (5,'Vĩnh Phúc',19,0,19,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (6,'Ninh Bình',13,0,13,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (7,'Bình Thuận',9,0,9,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (8,'Quảng Ninh',8,0,8,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (9,'Đà Nẵng',6,0,6,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (12,'Hà Tĩnh',4,0,4,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (14,'Hà Nam',4,0,4,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (11,'Bắc Giang',4,0,4,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (10,'Đồng Tháp',5,0,4,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (13,'Tây Ninh',4,0,4,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (4,'Bạc Liêu',21,0,7,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (16,'Thanh Hoá',3,0,3,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (15,'Quảng Nam',3,0,3,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (19,'Trà Vinh',2,0,2,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (18,'Cần Thơ',2,0,2,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (21,'Lào Cai ',2,0,2,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (22,'Thừa Thiên Huế',2,0,2,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (20,'Ninh Thuận',2,0,2,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (30,'Lai Châu',1,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (23,'Hưng Yên',1,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (27,'Bến Tre',1,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (25,'Hà Giang',1,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (28,'Bắc Ninh',1,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (24,'Đồng Nai',1,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (17,'Hải Dương',3,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (29,'Thái Nguyên',1,0,0,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (26,'Khánh Hoà',1,0,1,NULL);
INSERT INTO `se2db`.`vietnam` (`ID`,`Province`,`Total Infected`,`Total Deaths`,`Total Recovers`,`Day`) VALUES (3,'Thái Bình',30,0,5,NULL);
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '1');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '2');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '3');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '4');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '5');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '6');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '7');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '8');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '9');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '10');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '11');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '12');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '13');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '14');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '15');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '16');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '17');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '18');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '19');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '20');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '21');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '22');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '23');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '24');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '25');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '26');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '27');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '28');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '29');
UPDATE `se2db`.`vietnam` SET `Day` = '2020-05-29' WHERE (`ID` = '30');


CREATE TABLE `se2db`.`world` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `location` VARCHAR(126) NOT NULL,
  `total_cases` INT NULL,
  `total_deaths` INT NULL,
  `total_recovers` INT NULL,
  `new_cases` INT NULL,
  `new_deaths` INT NULL,
  `new_recovers` INT NULL,
  `date` DATE NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

CREATE TABLE `se2db`.`se2db_admin` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(64) NOT NULL,
  `password` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_unicode_ci;

INSERT INTO `se2db`.`se2db_admin` (`username`, `password`) VALUES ("admin", "admin");
INSERT INTO `se2db`.`se2db_admin` (`username`, `password`) VALUES ("duaf1xd", "duaf1xd");

