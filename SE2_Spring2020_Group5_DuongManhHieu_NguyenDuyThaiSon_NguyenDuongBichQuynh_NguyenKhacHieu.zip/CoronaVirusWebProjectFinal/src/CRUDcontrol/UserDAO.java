package CRUDcontrol;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import DBconnection.connect;
import model.Vietnam;
import model.World;
import servlet.ApiHomepage;

/**
 * This is a DAO (DATA ACCESS OBJECT) class which provides CRUD (CREATE - READ -
 * UPDATE - DELETE) database operations for the table user in the database
 */
public class UserDAO {
    public UserDAO() {
    }
    
    //login
    public boolean adminLogin(String username, String password) {
        
        Connection connection = connect.getConnection();
        try {
            
            String admlogin = "select * from se2db_admin where ( username = ? and password = ?)";
            PreparedStatement stm = connection.prepareStatement(admlogin);
            stm.setString(1, username);
            stm.setString(2, password);
            
            ResultSet result = stm.executeQuery();
            
            int rowcount = 0;
            if (result.last()) {
              rowcount = result.getRow();
              result.beforeFirst(); 
            }
            
            if (rowcount==0) return false;
            
            if (rowcount>0) {
            	ResultSetMetaData rsmd = result.getMetaData();
            	int columnsNumber = rsmd.getColumnCount();
            	while (result.next()) {
            	    for (int i = 1; i <= columnsNumber; i++) {
            	        if (i > 1) System.out.print(",  ");
            	        String columnValue = result.getString(i);
            	        System.out.print(columnValue + " " + rsmd.getColumnName(i));
            	    }
            	    System.out.println("");
            	}
            	return true;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    //VIETNAM TABLE
    
    public List<Vietnam> selectAllProvinces() {
        List<Vietnam> vietnams = new ArrayList<>();
        
        //Step 1: Establishing a Connection
        Connection connection = connect.getConnection();
        try {
            //Step 2: Create a statement using connection object
            String SELECT_ALL_PROVINCES = "select * from vietnam";
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_PROVINCES);
            
            //Step 3: Execute the query or update query
            ResultSet result = stm.executeQuery();
            
            //Step 4: Process the ResultSet object
            while (result.next()) {
                int id = result.getInt("ID");
                String province_name = result.getString("Province");
                int current_infected = result.getInt("Total Infected");
                int current_death = result.getInt("Total Deaths");
                int current_recovered = result.getInt("Total Recovers");
                String date = result.getString("Day");
                vietnams.add(new Vietnam(id, province_name, current_infected, current_death, current_recovered, date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vietnams;
    }
    
    //selectProvince() method to select particular Province by ID (use in UPDATE function)
    public Vietnam selectProvince(int id) {
        Vietnam vietnam = null;
        
        Connection connection = connect.getConnection();
        try {
            
            String SELECT_PROVINCE = "select * from vietnam where ID = ?";
            PreparedStatement stm = connection.prepareStatement(SELECT_PROVINCE);
            stm.setInt(1, id);
            
            ResultSet result = stm.executeQuery();
            
            if (result.next()) {
                String province_name = result.getString("Province");
                int current_infected = result.getInt("Total Infected");
                int current_death = result.getInt("Total Deaths");
                int current_recovered = result.getInt("Total Recovers");
                String date = result.getString("Day");
                vietnam = new Vietnam(id, province_name, current_infected, current_death, current_recovered, date);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return vietnam;
    }
    

    public List<World> selectAllCountries() {
        List<World> countries  = new ArrayList<>();
        
        Connection connection = connect.getConnection();
        try {
        	Instant ins= Instant.now();
        	String today= ApiHomepage.dateBuilder(ins.toString());
        	String dateParam= "'"+ today + "'";
        	System.out.println(dateParam);
            String SELECT_ALL_COUNTRIES = "select * from world where date= "+ dateParam;
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_COUNTRIES);
            ResultSet result = stm.executeQuery();
            while (result.next()) {
                String countryName = result.getString("location");
                int current_infected = result.getInt("total_cases");
                int current_death = result.getInt("total_deaths");
                int current_recovered = result.getInt("total_recovers");
                int new_infected = result.getInt("new_cases");
                int new_death = result.getInt("new_deaths");
                int new_recover= result.getInt("new_recovers");
                String date = result.getString("date");
                countries.add(new World(countryName, current_infected, current_death,
                		current_recovered, new_infected, new_death, new_recover, date));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return countries;
    }
    
    //selectCountry() method to select particular Country by ID (use in UPDATE function)
    public World selectCountry(String date) {
        World world = null;
        
        Connection connection = connect.getConnection();
        try {
            
            String SELECT_COUNTRY = "select * from world where date = '5/28/2020'";
            PreparedStatement stm = connection.prepareStatement(SELECT_COUNTRY);
            stm.setString(1, date);
            
            ResultSet result = stm.executeQuery();
            
            if (result.next()) {
                String country_name = result.getString("location");
                int current_infected = result.getInt("total_cases");
                int current_death = result.getInt("total_deaths");
                int current_recovered = result.getInt("total_recovers");
                int new_infected = result.getInt("new_cases");
                int new_death = result.getInt("new_deaths");
                world = new World(country_name, current_infected, current_death, current_recovered, new_infected, new_death);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return world;
    }
    
    
    //CHART
    public List<World> selectCountriesForPieChart() {
        List<World> countries  = new ArrayList<>();
        
        Connection connection = connect.getConnection();
        try {
        	Instant ins= Instant.now();
        	String today= ApiHomepage.dateBuilder(ins.toString());
        	String dateParam= "'"+ today + "'";
            String SELECT_COUNTRIES_FOR_CHART = "select location, total_cases from world where date = "+ dateParam+ " order by total_cases desc";
            PreparedStatement stm = connection.prepareStatement(SELECT_COUNTRIES_FOR_CHART);
            ResultSet result = stm.executeQuery();
            int count=0;
            while (result.next()) {
            	if(count==5) break;
                String country_name = result.getString("location");
                int current_infected = result.getInt("total_cases");
                countries.add(new World(country_name, current_infected));
                ++count;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return countries;
    }
    
    public List<World> selectCountriesForBarChart() {
        List<World> countries  = new ArrayList<>();
        
        Connection connection = connect.getConnection();
        try {
            String SELECT_COUNTRIES_FOR_BAR_CHART =
            		"select date, sum(total_cases) as total_cases, sum(total_deaths) as total_deaths, sum(total_recovers) as total_recovers from world where date between '2020-05-28' and '2020-06-06' group by date";
            PreparedStatement stm = connection.prepareStatement(SELECT_COUNTRIES_FOR_BAR_CHART);
            ResultSet result = stm.executeQuery();
            while (result.next()) {
            	String date = result.getString("date");
                int current_infected = result.getInt("total_cases");
                int current_death = result.getInt("total_deaths");
                int current_recovered = result.getInt("total_recovers");
                countries.add(new World(date, current_infected, current_death, current_recovered));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return countries;
    }

	public List<World> selectAllCountriesByDate(String dateParam) {

		String dateParam2= "'"+ dateParam+ "'";
        List<World> countries  = new ArrayList<>();
        
        Connection connection = connect.getConnection();
        try {
        	
            String SELECT_ALL_COUNTRIES = "select * from world where date= "+ dateParam2+ " order by location asc";
            System.out.println(SELECT_ALL_COUNTRIES);
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_COUNTRIES);
            ResultSet result = stm.executeQuery();
            int count= 0;
            while (result.next()) {
            	++count;
            	System.out.print(result.getString("location"));
                String countryName = result.getString("location");
                int current_infected = result.getInt("total_cases");
                int current_death = result.getInt("total_deaths");
                int current_recovered = result.getInt("total_recovers");
                int new_infected = result.getInt("new_cases");
                int new_death = result.getInt("new_deaths");
                int new_recover= result.getInt("new_recovers");
                String date = result.getString("date");
                countries.add(new World(countryName, current_infected, current_death,
                		current_recovered, new_infected, new_death, new_recover, date));
            }
            System.out.println("ResultSet from ACBD has "+ count +" records");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return countries;
	}

	public List<World> selectAllCountriesByLocation(String location) {
		System.out.println("selectAllCountriesByLocation executed with param "+ location);
		String locationParam= "'"+ location+ "'";
        List<World> countries  = new ArrayList<>();
        
        Connection connection = connect.getConnection();
        try {
        	
            String SELECT_ALL_COUNTRIES = "select * from world where location= "+ locationParam+ " order by date desc";
            System.out.println(SELECT_ALL_COUNTRIES);
            PreparedStatement stm = connection.prepareStatement(SELECT_ALL_COUNTRIES);
            ResultSet result = stm.executeQuery();
            int count= 0;
            while (result.next()) {
            	++count;
            	System.out.print(result.getString("location"));
                String countryName = result.getString("location");
                int current_infected = result.getInt("total_cases");
                int current_death = result.getInt("total_deaths");
                int current_recovered = result.getInt("total_recovers");
                int new_infected = result.getInt("new_cases");
                int new_death = result.getInt("new_deaths");
                int new_recover= result.getInt("new_recovers");
                String date = result.getString("date");
                countries.add(new World(countryName, current_infected, current_death,
                		current_recovered, new_infected, new_death, new_recover, date));
            }
            System.out.println("ResultSet from ACBD has "+ count +" records");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return countries;
	}
}
